package com.example.lab08.hesaplamalar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Alan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alan);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Alan ve Çevre Hesaplama");
    }
}

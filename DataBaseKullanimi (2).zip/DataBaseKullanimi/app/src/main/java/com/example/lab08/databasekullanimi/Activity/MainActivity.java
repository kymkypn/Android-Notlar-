package com.example.lab08.databasekullanimi.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lab08.databasekullanimi.R;


public class MainActivity extends AppCompatActivity {
    TextView adsoyad , email , dogum_yili,silid;
    Button uyeEkle,guncelle,sil,liste;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StringBuilder sb=new StringBuilder();
        sb.append("CREATE TABLE IF NOT EXISTS Uyeler");
        sb.append("(");
        sb.append("id INTEGER PRIMARY KEY AUTOINCREMENT ,");
        sb.append("adsoyad TEXT,");
        sb.append("email TEXT,");
        sb.append("dogum_yili INTEGER");
        sb.append(")");

        tabloEkle("mydb",sb.toString());


        adsoyad=findViewById(R.id.adsoyad);
        email=findViewById(R.id.mail);
        dogum_yili=findViewById(R.id.dogum_yili);
        uyeEkle=findViewById(R.id.uyeEkle);
        silid=findViewById(R.id.uyeSilid);
        guncelle=findViewById(R.id.guncelle);
        sil=findViewById(R.id.uyeSil);
        liste=findViewById(R.id.listele);
        linearLayout=findViewById(R.id.linearLayout);



        uyeEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeEkle("mydb",
                        adsoyad.getText().toString(),
                        email.getText().toString(),
                        Integer.parseInt(dogum_yili.getText().toString()));
            }
        });
        guncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        sil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeSil("mydb",Integer.parseInt(silid.getText().toString()));
            }
        });
        liste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeListele("mydb","Uyeler");
            }
        });





    }


    public void tabloEkle (String dbName , String sorgu){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE , null);
        db.execSQL(sorgu);
    }

    public void uyeEkle(String dbName, String uyeadsoyad, String uyeMail, int dogum_yili){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE , null);
        //db.execSQL("Create Table if not exists Uyeler (id INTEGER PRIMARY KEY, Name varchar, Surname varchar, Age int(3));");
        db.execSQL("insert into Uyeler values(NULL,'"+uyeadsoyad+"','"+uyeMail+"',"+dogum_yili+")");
    }
    public void uyeGuncelle(String dbName,int userId,String uyeAdi,String uyeSoyadi){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL("update Uyeler SET Name='"+uyeAdi+"',Surname='"+uyeSoyadi+"' where id='"+userId+"'");
    }
    public  void uyeSil(String dbName,int userId){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL("delete from Uyeler where id='"+userId+"'");
    }
    public void uyeListele(String dbName, String tableName){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        Cursor c = db.rawQuery("Select * from '"+tableName+"'",null);
        c.moveToFirst();
        //StringBuilder bld= new StringBuilder("");
        linearLayout.removeAllViews();
        do{
            //bld.append(c.getString(0) +" "+ c.getString(1) + " "+c.getInt(2) +"");
            TextView iclinear=new TextView(getApplicationContext());
            iclinear.setText(c.getString(c.getColumnIndex("adsoyad")));
            linearLayout.addView(iclinear);

        }while(c.moveToNext());

    }
}

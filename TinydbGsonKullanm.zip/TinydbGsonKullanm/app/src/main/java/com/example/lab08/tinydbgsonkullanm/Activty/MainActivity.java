package com.example.lab08.tinydbgsonkullanm.Activty;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.lab08.tinydbgsonkullanm.Helper.Tinydb;
import com.example.lab08.tinydbgsonkullanm.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Tinydb tinydb = new Tinydb(getApplicationContext());

        ArrayList< String > egitimDurumlari = new ArrayList< >();
        egitimDurumlari.add("Lise");
        egitimDurumlari.add("Ön Lisans");
        egitimDurumlari.add("Lisans");
        egitimDurumlari.add("Yüksek Lisans");
        egitimDurumlari.add("Doktora");

//String tipindeki ArrayList değerlerini atama
        tinydb.putListString("egitimdurumlari",egitimDurumlari);

//String tipindeki ArrayList değerlerini okuma
        ArrayList< String > str = tinydb.getListString( "egitimdurumlari" );
        for(int i=0; i < str.size(); i++ ){
            Log.d( "LOG" ,str.get(i));
        }


    }
}

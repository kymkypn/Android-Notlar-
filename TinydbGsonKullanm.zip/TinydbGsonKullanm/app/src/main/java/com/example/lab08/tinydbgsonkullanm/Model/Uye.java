package com.example.lab08.tinydbgsonkullanm.Model;

public class Uye {

        private int id;
        private String ad;
        private String mail;
    public Uye() {
    }

    public Uye(int id, String ad, String mail) {
        this.id = id;
        this.ad = ad;
        this.mail = mail;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}


package com.example.lab08.hesaplamalar.Hesaplar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lab08.hesaplamalar.R;

public class Yuzde extends AppCompatActivity {

    EditText sayi1 , sayi2;
    Button durum1,durum2;
    TextView sonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yuzde);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Yüzde Hesaplama");

        sayi1=findViewById(R.id.sayi1);
        sayi2=findViewById(R.id.sayi2);

        sonuc=findViewById(R.id.sonuc);

        durum1=findViewById(R.id.durum1);
        durum2=findViewById(R.id.durum2);

        durum1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double sayia=Double.parseDouble(sayi1.getText().toString());
                double sayib=Double.parseDouble(sayi2.getText().toString());

                double cevap=sayib/100*sayia;
                sonuc.setText("Sonuç : "+cevap);
            }
        });

        durum2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double sayia=Double.parseDouble(sayi1.getText().toString());
                double sayib=Double.parseDouble(sayi2.getText().toString());

                double cevap=sayia/100*sayib;
                sonuc.setText("Sonuç : "+cevap);
            }
        });



    }
}

package com.example.lab08.hesaplamalar.Hesaplar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lab08.hesaplamalar.R;

public class AltinOran extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_altin_oran);
    }
}

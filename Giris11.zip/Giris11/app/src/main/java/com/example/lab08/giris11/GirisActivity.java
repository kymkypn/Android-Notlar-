package com.example.lab08.giris11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GirisActivity extends AppCompatActivity {
    EditText isim,sifre;
    Button giris;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giris);

        isim=findViewById(R.id.isim);
        sifre=findViewById(R.id.sifre);
        giris=findViewById(R.id.giris);




        giris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String kullanicigel=isim.getText().toString();
                String sifregel=sifre.getText().toString();

                if ("admin".equals(kullanicigel) && "1234".equals(sifregel)){
                    Intent i= new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(i);
                }else {
                    Toast.makeText(getApplicationContext(),"Kullanıcı Adı veya şifre hatalı",Toast.LENGTH_LONG);
                }






            }
        });





    }
}

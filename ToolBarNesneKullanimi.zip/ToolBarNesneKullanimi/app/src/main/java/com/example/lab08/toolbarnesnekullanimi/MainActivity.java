package com.example.lab08.toolbarnesnekullanimi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button tus11;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tus11=findViewById(R.id.tus11);

        tus11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(i);
            }
        });






        //başlıklar
        //this.setTitle("Ana Sayfa");
        getSupportActionBar().setTitle("Ana Sayfa");
        getSupportActionBar().setSubtitle("Alt Başlık");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //tıklanan menü item yakalama
        if (item.getItemId()==R.id.id_favori){
            Toast.makeText(getApplicationContext(),"Favoriler",Toast.LENGTH_LONG).show();
        }else if (item.getItemId()==R.id.id_hakkimizda){
            Toast.makeText(getApplicationContext(),"Hakkımızda",Toast.LENGTH_LONG).show();
        }else if (item.getItemId()==R.id.id_play){
            Toast.makeText(getApplicationContext(),"Google Play",Toast.LENGTH_LONG).show();
        }else if (item.getItemId()==R.id.ıd_iletisim){
            Toast.makeText(getApplicationContext(),"İletişim",Toast.LENGTH_LONG).show();
        }



        return super.onOptionsItemSelected(item);
    }
}

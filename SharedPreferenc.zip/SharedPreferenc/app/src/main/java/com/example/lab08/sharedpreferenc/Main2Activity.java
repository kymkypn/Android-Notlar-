package com.example.lab08.sharedpreferenc;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.app.SupportActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView gelen;

    SharedPreferences sp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        gelen=findViewById(R.id.gelen);

        gelen.setText(sp.getString("mesaj",""));




    }
}

package com.example.lab08.sharedpreferenc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText isim;
    Button gonder;


    SharedPreferences sp;// tanımlı değer çağırır
    SharedPreferences.Editor spe;//ekle sil güncelle işlemleri shared preferens  editörü kullanılır

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isim=findViewById(R.id.isim);
        gonder=findViewById(R.id.tus);


        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe= sp.edit();

        isim.setText(sp.getString("mesaj",""));

        gonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //shared preferens için kayıt için put metodu kullan
                spe.putString("mesaj",isim.getText().toString());
                spe.commit();//değişikliği kaydetme
                startActivity(new Intent(getApplicationContext(),Main2Activity.class));






            }
        });




    }
}

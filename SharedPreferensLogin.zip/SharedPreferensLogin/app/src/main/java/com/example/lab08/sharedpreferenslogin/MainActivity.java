package com.example.lab08.sharedpreferenslogin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText kullaniciAdi , sifre;
    CheckBox hatirla;
    Button gonder;
    SharedPreferences sp;
    SharedPreferences.Editor spe;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kullaniciAdi=findViewById(R.id.kullaniciAdi);
        sifre=findViewById(R.id.sifre);

        hatirla=findViewById(R.id.hatirla);

        gonder=findViewById(R.id.gonder);


        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe=sp.edit();



        if (sp.getInt("remember",0)==0){

            sifre.setText("");
            kullaniciAdi.setText("");
            hatirla.setChecked(false);


        }else if (sp.getInt("remember",0)==1){
            kullaniciAdi.setText(sp.getString("kAdi",""));
            sifre.setText(sp.getString("kSifre",""));
            hatirla.setChecked(false);

        }



        gonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //boş dolu kullanımı
                if (!"".equals(kullaniciAdi)&&!"".equals(sifre)){

                    if (hatirla.isChecked()){
                        spe.putString("kAdi",kullaniciAdi.getText().toString());
                        spe.putString("kSifre",sifre.getText().toString());
                        spe.putInt("remember",1);
                        spe.commit();

                    }else {
                        spe.putString("kAdi", "");
                        spe.putString("kSifre", "");
                        spe.putInt("remember", 0);
                        spe.commit();
                    }
                    startActivity(new Intent(getApplicationContext(),Main2Activity.class));

                }else{
                    Toast.makeText(getApplicationContext(),"Kullanıcı adı ve şifre boş geçilemez",Toast.LENGTH_LONG).show();




                }
            }
        });






    }
}

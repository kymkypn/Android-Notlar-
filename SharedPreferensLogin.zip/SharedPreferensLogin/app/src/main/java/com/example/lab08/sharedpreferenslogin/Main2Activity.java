package com.example.lab08.sharedpreferenslogin;

import android.content.PeriodicSync;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {
    EditText et1,et2;
    SharedPreferences sp;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        et1.setText(sp.getString("kAdi",""));
        et2.setText(sp.getString("kSifre",""));



    }
}
